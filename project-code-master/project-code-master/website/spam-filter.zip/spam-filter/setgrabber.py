import twitter
import sys
import openpyxl

api = twitter.Api(consumer_key='VCdvhstRuvP6rcyezRGFz11Ou',
                  consumer_secret='Zob9WMUprTHwNwQkMz9TrBziyuPAiUmxIIIEsnjVm7IJtAFbfu',
                  access_token_key='1061939344246800384-flQTkjF4QrrE2TMQ74bXjdrksPzdTg',
                  access_token_secret='9ZB8TxxvlvPFtgR12KeRCDsLH9RGcjpj9Jcf2y7k4cS24')

#Location of the source dataset: hardcoded in this case, would need to be a spreadsheet with tweet ids in column A and
#a spam/non-spam label in column B if changed.
sheet_location = "journal.pone.0182487.s003.xlsx"


def grab_100(initial):
    wb = openpyxl.load_workbook(filename=sheet_location)
    ws = wb.active

    tweet_ids = {}
    cell_number = initial
    #Based explicitly on hard coded spreadsheet, where data starts in row 6.
    for x in range(cell_number + 5, cell_number + 104):
        id_location = "A" + str(x)
        label_location = "B" + str(x)
        if ws[id_location].value is None:
            break
        tweet_ids[ws[id_location].value] = ws[label_location].value

    retrieved_tweets = api.GetStatuses(list(tweet_ids.keys()), map=True)

    i = 0
    for y in tweet_ids:
        if retrieved_tweets[int(y)] is not None:
            directory = ""
            if tweet_ids[y] == 0:
                directory = "datasets/non-spam/"
            else:
                directory = "datasets/spam/"
            filename = directory + "tweet_" + str(cell_number + i) + ".txt"
            file = open(filename, mode="w+", encoding="utf-8")
            file.write(retrieved_tweets[int(y)].text)
            file.close()
            i += 1
