import re
import pickle
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
from sklearn.datasets import load_files
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.ensemble import RandomForestClassifier

tweet_data = load_files(container_path=r"datasets", encoding="utf-8", random_state=1)
X = tweet_data.data
y = tweet_data.target

processed_tweet_data = []
stemmer = WordNetLemmatizer()

for i in range(0, len(X)):
    # remove all single characters
    tweet = re.sub(r'\s+[a-zA-Z]\s+', ' ', str(X[i]))

    # Remove single characters from the start
    tweet = re.sub(r'\^[a-zA-Z]\s+', ' ', tweet) 

    # Substituting multiple spaces with single space
    tweet = re.sub(r'\s+', ' ', tweet, flags=re.I)

    # Removing prefixed 'b'
    tweet = re.sub(r'^b\s+', '', tweet)

    # Converting to Lowercase
    tweet = tweet.lower()

    # Lemmatization
    tweet = tweet.split()

    tweet = [stemmer.lemmatize(word) for word in tweet]
    tweet = ' '.join(tweet)

    processed_tweet_data.append(tweet)

# Converts the preprocessed tweet data into a set of TFIDF feature values.
count_converter = CountVectorizer(max_features=1500, min_df=5, max_df=0.8, stop_words=stopwords.words('english'))
X = count_converter.fit_transform(processed_tweet_data).toarray()

tfidf_converter = TfidfTransformer()
X = tfidf_converter.fit_transform(X).toarray()

# Splits source data into training and testing data at random.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
# Trains and tests model based on split data.
classifier = RandomForestClassifier(n_estimators=1000, random_state=0)
classifier.fit(X_train, y_train)
y_pred = classifier.predict(X_test)

# Prints model metrics.
print(confusion_matrix(y_test,y_pred))
print(classification_report(y_test,y_pred))
print(accuracy_score(y_test, y_pred))

# Saves model and vectorizer for preprocessing.
with open('text_classifier', 'wb') as picklefile:
    pickle.dump(classifier, picklefile)
with open('text_converter', 'wb') as picklefile:
    pickle.dump(count_converter, picklefile)
