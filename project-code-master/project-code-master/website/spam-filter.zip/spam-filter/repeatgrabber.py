import sys
import setgrabber

i = 0
set_entries = 100000
if len(sys.argv) > 1:
    i = int(sys.argv[1])
else:
    i = 1

while i < set_entries:
    setgrabber.grab_100(i)
    i += 100
    print("Completed " + str(i))