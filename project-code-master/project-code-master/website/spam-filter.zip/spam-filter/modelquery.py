import re
import pickle
import sys
from nltk.stem import WordNetLemmatizer
import json
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestClassifier


class ModelQuery:
    model = None
    classifier = None

    def __init__(self):
        with open('text_classifier', 'rb') as saved_model:
            self.model = pickle.load(saved_model)
        with open('text_converter', 'rb') as saved_converter:
            self.converter = pickle.load(saved_converter)

    def runquery(self, sourcetweet):
        stemmer = WordNetLemmatizer()

        # remove all single characters
        tweet = re.sub(r'\s+[a-zA-Z]\s+', ' ', sourcetweet)

        # Remove single characters from the start
        tweet = re.sub(r'\^[a-zA-Z]\s+', ' ', tweet)

        # Substituting multiple spaces with single space
        tweet = re.sub(r'\s+', ' ', tweet, flags=re.I)

        # Removing prefixed 'b'
        tweet = re.sub(r'^b\s+', '', tweet)

        # Converting to Lowercase
        tweet = tweet.lower()

        # Lemmatization
        tweet = tweet.split()

        tweet = [stemmer.lemmatize(word) for word in tweet]
        tweet = ' '.join(tweet)

        X = self.converter.transform([tweet]).toarray()
        prediction = self.model.predict(X)
        # Non-spam should correspond to a value of 0, and spam to a value of 1.
        print(prediction[0])


if __name__ == '__main__':
    m = ModelQuery()
    while True:
        inp = input()
        inp = json.loads(inp)
        m.runquery(inp)
