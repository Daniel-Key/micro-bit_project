import twitter
import sys

api = twitter.Api(consumer_key='VCdvhstRuvP6rcyezRGFz11Ou',
                  consumer_secret='Zob9WMUprTHwNwQkMz9TrBziyuPAiUmxIIIEsnjVm7IJtAFbfu',
                  access_token_key='1061939344246800384-flQTkjF4QrrE2TMQ74bXjdrksPzdTg',
                  access_token_secret='9ZB8TxxvlvPFtgR12KeRCDsLH9RGcjpj9Jcf2y7k4cS24')

non_spam_tweets = []
if len(sys.argv) > 1:
    i = int(sys.argv[1])
    non_spam_tweets = api.GetSearch(term="the", count=100)
    for x in non_spam_tweets:
        filename = "datasets/non-spam/non_spam_tweet_" + str(i) + ".txt"
        file = open(filename, mode="w+", encoding="utf-8")
        file.write(x.text)
        file.close()
        i += 1
